window.model = {
    data: {
        items: [
            // {msg:'', completed: false}
        ],
        imp: 'All',
        msg: '',
        filter: 'All'
    },
    TOKEN: 'DoOrDie'

    // data provider interface
    // init: null
    // flush: null
};